# Portfolio Website
Simple portfolio website designed to showcase projects, skills, and experience

## Description

This is a portfolio website built using HTML, CSS, and JavaScript.

